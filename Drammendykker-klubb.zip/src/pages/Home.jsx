import Hero from './sections/index/Hero'
import CalendarPreview from './sections/index/CalendarPreview'
import FacebookPreview from './sections/index/FacebookPreview'

const Home = () => {
  return (
    <>
      <Hero />
    </>
  )
}

export default Home

